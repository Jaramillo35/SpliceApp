# DTx Compare Report - Windows Distribution

## Download

Use this package file:

`DTx_Compare_Distribution_Windows_v1.0.zip`

## Install Instructions

Open:

`INSTALL_WINDOWS.md`

## One-line usage

Double-click `DTx_Compare_Report.exe`, select OLD file, select NEW file, get output report.
