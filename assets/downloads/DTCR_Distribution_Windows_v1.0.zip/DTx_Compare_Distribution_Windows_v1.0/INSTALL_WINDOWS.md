# Install DTx Compare on Windows

## 1. Download

Download this package:

DTx_Compare_Distribution_Windows_v1.0.zip

## 2. Extract

1. Right-click the zip file.
2. Click `Extract All...`.
3. Open the extracted folder.

## 3. Run (if executable already exists)

1. Open: `DTx_Compare_Source_v1.0/dist/DTx_Compare_Report`
2. Double-click: `DTx_Compare_Report.exe`
3. Pick the OLD DTx file.
4. Pick the NEW DTx file.
5. Done. The output Excel report is saved near the NEW DTx file.

## 4. If `.exe` is missing, build it once

1. Open folder: `DTx_Compare_Source_v1.0`
2. Double-click: `build_windows.bat`
3. Wait for "Build complete".
4. Go to: `dist/DTx_Compare_Report`
5. Double-click: `DTx_Compare_Report.exe`

## Troubleshooting

- SmartScreen warning:
  - Click `More info` then `Run anyway`.
- App does not open:
  - Make sure `.exe` and `_internal` are in the same folder.
- Build fails:
  - Install Python 3.10+ from https://www.python.org/downloads/windows/
  - Run `build_windows.bat` again.
