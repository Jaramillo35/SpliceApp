@echo off
setlocal

echo ================================================================
echo DTx Compare Report - Windows Builder
echo ================================================================

echo [1/5] Checking Python...
where python >nul 2>&1
if errorlevel 1 (
  echo ERROR: Python is not installed or not in PATH.
  echo Install Python 3.10+ from https://www.python.org/downloads/windows/
  pause
  exit /b 1
)

echo [2/5] Creating virtual environment...
if not exist .venv (
  python -m venv .venv
)

call .venv\Scripts\activate
if errorlevel 1 (
  echo ERROR: Could not activate virtual environment.
  pause
  exit /b 1
)

echo [3/5] Installing dependencies...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo ERROR: Dependency install failed.
  pause
  exit /b 1
)

echo [4/5] Building executable with PyInstaller...
pyinstaller --noconfirm --clean --windowed --onedir --name "DTx_Compare_Report" dtx_compare_report.py
if errorlevel 1 (
  echo ERROR: PyInstaller build failed.
  pause
  exit /b 1
)

echo [5/5] Build complete.
echo Output folder:
echo %cd%\dist\DTx_Compare_Report

echo.
echo NEXT:
echo 1) Open dist\DTx_Compare_Report
echo 2) Double-click DTx_Compare_Report.exe
echo 3) Keep .exe and _internal folder together

pause
endlocal
