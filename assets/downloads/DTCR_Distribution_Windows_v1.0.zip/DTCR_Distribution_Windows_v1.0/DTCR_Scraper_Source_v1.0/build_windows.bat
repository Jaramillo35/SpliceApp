@echo off
setlocal

echo ================================================================
echo DTCR Scraper - Windows Builder
echo ================================================================

echo [1/6] Checking Python...
where python >nul 2>&1
if errorlevel 1 (
  echo ERROR: Python is not installed or not in PATH.
  echo Install Python 3.10+ from https://www.python.org/downloads/windows/
  pause
  exit /b 1
)

echo [2/6] Creating virtual environment...
if not exist .venv (
  python -m venv .venv
)

call .venv\Scripts\activate
if errorlevel 1 (
  echo ERROR: Could not activate virtual environment.
  pause
  exit /b 1
)

echo [3/6] Installing dependencies...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo ERROR: Dependency install failed.
  pause
  exit /b 1
)

echo [4/6] Installing Playwright Chromium...
python -m playwright install chromium
if errorlevel 1 (
  echo ERROR: Playwright browser install failed.
  pause
  exit /b 1
)

echo [5/6] Building executable...
pyinstaller --noconfirm --clean --windowed --onedir --name "DTCR_Scraper" master_scraper.py
if errorlevel 1 (
  echo ERROR: PyInstaller build failed.
  pause
  exit /b 1
)

echo [6/6] Build complete.
echo Output folder:
echo %cd%\dist\DTCR_Scraper

echo.
echo NEXT:
echo 1) Open dist\DTCR_Scraper
echo 2) Double-click DTCR_Scraper.exe
echo 3) Keep .exe and _internal folder together

pause
endlocal
