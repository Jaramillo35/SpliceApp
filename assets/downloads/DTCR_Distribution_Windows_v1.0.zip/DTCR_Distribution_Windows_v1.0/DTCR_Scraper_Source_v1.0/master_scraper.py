"""
DTCR Master Scraper
Orchestrates manual-assisted login/search and automated DTCR attachment download.
"""

import asyncio
from playwright.async_api import async_playwright
import logging

from session_manager import SessionManager
from dtcr_scraper import DTCRScraper

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# URLs
CHRYSLER_LOGIN_URL = "https://login.chrysler.com/siteminderagent/forms/chryslerlogin.fcc?TYPE=33554433&REALMOID=06-3f2a4016-f13a-0076-0000-31e7000031e7&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=-SM-%2bWLpSgscRfpSwghGeXnNG1dvGOs%2bFyz1jzikB8V%2fvy%2bVofPVokIbhkuBaeIevVBwV5%2fnWaXHP4IzVfRYlCE7Gg3OqtvJTcVV&TARGET=-SM-https%3a%2f%2fispeed%2eextra%2echrysler%2ecom%2fispeed%2findex%2ehtml"
ISPEED_URL = "https://ispeed.extra.chrysler.com/ispeed/index.html"


async def show_visual_prompt(page, title, message_lines):
    """Display an in-page overlay prompt for manual user actions."""
    try:
        await page.evaluate(
            """
            ({ title, lines }) => {
                const old = document.getElementById('copilot-manual-prompt');
                if (old) old.remove();

                const wrap = document.createElement('div');
                wrap.id = 'copilot-manual-prompt';
                wrap.style.position = 'fixed';
                wrap.style.top = '16px';
                wrap.style.right = '16px';
                wrap.style.zIndex = '999999';
                wrap.style.maxWidth = '420px';
                wrap.style.background = '#103b6d';
                wrap.style.color = '#fff';
                wrap.style.borderRadius = '10px';
                wrap.style.padding = '14px 16px';
                wrap.style.boxShadow = '0 6px 20px rgba(0,0,0,0.3)';
                wrap.style.fontFamily = 'Arial, sans-serif';
                wrap.style.fontSize = '14px';

                const h = document.createElement('div');
                h.style.fontWeight = '700';
                h.style.marginBottom = '8px';
                h.textContent = title;

                const ul = document.createElement('ul');
                ul.style.margin = '0';
                ul.style.paddingLeft = '18px';
                for (const line of lines) {
                    const li = document.createElement('li');
                    li.style.marginBottom = '4px';
                    li.textContent = line;
                    ul.appendChild(li);
                }

                wrap.appendChild(h);
                wrap.appendChild(ul);
                document.body.appendChild(wrap);
            }
            """,
            {"title": title, "lines": message_lines},
        )
    except Exception:
        # Ignore when the page is transitioning or was replaced by a new tab.
        pass


async def clear_visual_prompt(page):
    """Remove in-page overlay prompt."""
    try:
        await page.evaluate(
            """
            () => {
                const el = document.getElementById('copilot-manual-prompt');
                if (el) el.remove();
            }
            """
        )
    except Exception:
        pass


def get_active_page(context, current_page):
    """Return a live page, preferring current if still open, otherwise latest context page."""
    try:
        if current_page and not current_page.is_closed():
            return current_page
    except Exception:
        pass

    live_pages = [p for p in context.pages if not p.is_closed()]
    if live_pages:
        return live_pages[-1]
    return current_page


async def wait_for_manual_login(context, page, session_manager):
    """Open login URL and wait for user to complete login manually."""
    logger.info("Opening login page for manual sign-in...")
    await page.goto(CHRYSLER_LOGIN_URL, wait_until="domcontentloaded", timeout=20000)

    await show_visual_prompt(
        page,
        "Manual Login Required",
        [
            "Enter User ID and Password.",
            "Click Sign In.",
            "Wait until iSPEED home is visible.",
            "Return to terminal and press Enter."
        ],
    )

    # Place listeners on click/submit so the flow can continue automatically.
    await page.evaluate(
        """
        () => {
            window.__copilotSignInClicked = false;

            const markClicked = () => { window.__copilotSignInClicked = true; };

            const btn = document.querySelector('#login-btn');
            if (btn) {
                btn.addEventListener('click', markClicked, { once: true });
            }

            const form = document.querySelector('form');
            if (form) {
                form.addEventListener('submit', markClicked, { once: true });
            }
        }
        """
    )

    logger.info("Waiting for user to click Sign In...")

    clicked = False
    for _ in range(360):
        page = get_active_page(context, page)
        try:
            clicked = await page.evaluate("() => window.__copilotSignInClicked === true")
        except Exception:
            clicked = False

        # If the page already redirected, continue even if listener state was lost.
        current_url = ""
        try:
            current_url = page.url
        except Exception:
            pass

        if clicked or ("ispeed.extra.chrysler.com" in current_url and "login.chrysler.com" not in current_url):
            break

        await asyncio.sleep(0.5)

    if not clicked:
        logger.warning("Sign In listener did not fire before timeout; continuing if redirected")

    try:
        await page.wait_for_load_state("domcontentloaded", timeout=30000)
    except Exception:
        pass

    try:
        await page.wait_for_load_state("networkidle", timeout=15000)
    except Exception:
        pass

    await clear_visual_prompt(page)
    await session_manager.save_session(page, "manual_login")
    logger.info(f"Current URL after login: {page.url}")
    return True, page


async def wait_for_user_search_and_download_click(context, page):
    """
    Keep a visible GUI prompt with a Download button while user performs manual steps:
    login, Change Requests navigation, Program/Phase input, and Search click.
    Automation starts only when user clicks Download.
    """
    logger.info("Waiting for user to complete manual setup and click Download...")

    panel_script = """
        () => {
            if (typeof window.__copilotDownloadClicked === 'undefined') {
                window.__copilotDownloadClicked = false;
            }

            let panel = document.getElementById('copilot-download-panel');
            if (!panel) {
                panel = document.createElement('div');
                panel.id = 'copilot-download-panel';
                panel.style.position = 'fixed';
                panel.style.top = '16px';
                panel.style.right = '16px';
                panel.style.zIndex = '2147483647';
                panel.style.maxWidth = '420px';
                panel.style.background = '#103b6d';
                panel.style.color = '#fff';
                panel.style.borderRadius = '10px';
                panel.style.padding = '14px 16px';
                panel.style.boxShadow = '0 6px 20px rgba(0,0,0,0.3)';
                panel.style.fontFamily = 'Arial, sans-serif';
                panel.style.fontSize = '14px';

                const title = document.createElement('div');
                title.style.fontWeight = '700';
                title.style.marginBottom = '8px';
                title.textContent = 'Manual Steps Before Download';

                const list = document.createElement('ul');
                list.style.margin = '0 0 10px 0';
                list.style.paddingLeft = '18px';
                const steps = [
                    'Sign in with User ID and Password.',
                    'Open Change Requests tab.',
                    'Input Program and Phase.',
                    'Click Search and wait results.'
                ];
                for (const step of steps) {
                    const li = document.createElement('li');
                    li.textContent = step;
                    li.style.marginBottom = '4px';
                    list.appendChild(li);
                }

                const btn = document.createElement('button');
                btn.id = 'copilot-download-button';
                btn.textContent = 'Download';
                btn.style.background = '#f39c12';
                btn.style.border = '0';
                btn.style.borderRadius = '8px';
                btn.style.color = '#fff';
                btn.style.fontWeight = '700';
                btn.style.padding = '8px 14px';
                btn.style.cursor = 'pointer';
                btn.onclick = () => {
                    window.__copilotDownloadClicked = true;
                    btn.textContent = 'Starting...';
                    btn.disabled = true;
                    btn.style.opacity = '0.7';
                };

                panel.appendChild(title);
                panel.appendChild(list);
                panel.appendChild(btn);
                document.body.appendChild(panel);
            }

            if (window.__copilotDownloadClicked === true) {
                const btn = document.getElementById('copilot-download-button');
                if (btn) {
                    btn.textContent = 'Starting...';
                    btn.disabled = true;
                    btn.style.opacity = '0.7';
                }
            }

            return window.__copilotDownloadClicked === true;
        }
    """

    while True:
        page = get_active_page(context, page)
        clicked_any = False

        # Inject in all live pages and their frames so panel survives tab/frame switches.
        for p in [p for p in context.pages if not p.is_closed()]:
            targets = [p.main_frame] + [f for f in p.frames if f != p.main_frame]
            for target in targets:
                try:
                    clicked = await target.evaluate(panel_script)
                    if clicked:
                        clicked_any = True
                        page = p
                except Exception:
                    continue

        if clicked_any:
            logger.info("✓ Download button clicked. Starting DTCR processing...")
            await clear_visual_prompt(page)
            try:
                await page.evaluate(
                    """
                    () => {
                        const p = document.getElementById('copilot-download-panel');
                        if (p) p.remove();
                    }
                    """
                )
            except Exception:
                pass
            return page

        await asyncio.sleep(1)


async def navigate_to_change_requests(context, page):
    """Navigate to Change Requests tab/menu automatically."""
    logger.info("Navigating to Change Requests...")

    selectors = [
        "text=Change Requests",
        "text=Change Request",
        "a:has-text('Change Requests')",
        "a:has-text('Change Request')",
        "button:has-text('Change Requests')",
        "button:has-text('Change Request')"
    ]

    page = get_active_page(context, page)
    targets = [page] + list(page.frames)
    for target in targets:
        for selector in selectors:
            try:
                await target.click(selector, timeout=2500)
                await asyncio.sleep(1)
                try:
                    await page.wait_for_load_state("networkidle", timeout=12000)
                except Exception:
                    pass
                logger.info("✓ Change Requests page opened")
                page = get_active_page(context, page)
                return True, page
            except Exception:
                continue

    # Fallback: ask user to click manually if automatic navigation fails.
    logger.warning("Could not open Change Requests page automatically; requesting manual click")
    await show_visual_prompt(
        page,
        "Manual Navigation Required",
        [
            "Click the 'Change Requests' tab/menu.",
            "Wait until the Change Requests page is visible.",
            "Return to terminal and press Enter."
        ],
    )
    input("\nManual step: click Change Requests in browser, then press Enter... ")
    page = get_active_page(context, page)
    await clear_visual_prompt(page)
    return True, page


async def wait_for_manual_search(context, page):
    """Prompt user to fill Program/Phase and click Search manually."""
    await show_visual_prompt(
        page,
        "Manual Search Input",
        [
            "Fill Program and Phase fields.",
            "Click Search.",
            "Wait until the results table appears.",
            "Return to terminal and press Enter."
        ],
    )

    input("\nManual step: fill Program/Phase and click Search, then press Enter here... ")
    page = get_active_page(context, page)

    try:
        await page.wait_for_load_state("networkidle", timeout=15000)
    except Exception:
        pass

    await asyncio.sleep(2)
    await clear_visual_prompt(page)
    return page


async def main():
    """Main orchestration function"""
    
    logger.info("Starting DTCR Master Scraper...")
    
    # Initialize managers
    session_manager = SessionManager()
    
    try:
        # Launch browser
        logger.info("Launching browser...")
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=False)
            context = await browser.new_context()
            page = await context.new_page()
            
            # Open login URL and let user perform all pre-download steps manually.
            logger.info("Opening login page...")
            await page.goto(CHRYSLER_LOGIN_URL, wait_until="domcontentloaded", timeout=20000)
            page = await wait_for_user_search_and_download_click(context, page)

            # Continue automated processing from loaded results table.
            logger.info("\nInitializing DTCR Scraper from current session...")
            scraper = DTCRScraper(
                base_url=ISPEED_URL,
                download_dir="dtcr_downloads"
            )

            scraper.attach_page(page)
            results = await scraper.process_current_results()
            
            # Print results
            print("\n" + "="*60)
            print("SCRAPING RESULTS")
            print("="*60)
            
            if results.get("success"):
                print(f"Total DTCRs found: {results.get('total_dtcrs')}")
                print(f"Successfully processed: {results.get('processed')}")
                print(f"Failed: {results.get('failed')}")
                print(f"\nDownloads saved to: {scraper.download_dir.absolute()}")

                excel_path = scraper.export_reason_for_change_excel(results)
                print(f"Reason-for-change Excel: {excel_path}")
                
                # List downloaded DTCRs
                if results.get('dtcrs'):
                    print("\nDownloaded DTCRs:")
                    for dtcr_num, dtcr_info in results.get('dtcrs', {}).items():
                        status = "✓" if dtcr_info.get('success') else "✗"
                        print(f"  {status} {dtcr_num}: {dtcr_info.get('folder')}")
            else:
                print(f"Error: {results.get('error')}")
            
            print("="*60)

            try:
                if browser.is_connected():
                    await browser.close()
            except Exception:
                pass
            
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    print("\n" + "="*60)
    print("DTCR MASTER SCRAPER")
    print("="*60)
    print(" Login → Search → Download → Organize")
    print("="*60 + "\n")
    
    asyncio.run(main())
