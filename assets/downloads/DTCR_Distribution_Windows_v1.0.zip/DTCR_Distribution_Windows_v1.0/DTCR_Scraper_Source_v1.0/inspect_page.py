"""
Page Inspector - Find form field selectors
"""

import asyncio
from playwright.async_api import async_playwright
import json

LOGIN_URL = "https://login.chrysler.com/siteminderagent/forms/chryslerlogin.fcc?TYPE=33554433&REALMOID=06-3f2a4016-f13a-0076-0000-31e7000031e7&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=-SM-%2bWLpSgscRfpSwghGeXnNG1dvGOs%2bFyz1jzikB8V%2fvy%2bVofPVokIbhkuBaeIevVBwV5%2fnWaXHP4IzVfRYlCE7Gg3OqtvJTcVV&TARGET=-SM-https%3a%2f%2fispeed%2eextra%2echrysler%2ecom%2fispeed%2findex%2ehtml"


async def inspect_page():
    """Inspect the login page and find form field selectors"""
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)  # Show browser for inspection
        context = await browser.new_context(viewport={'width': 1280, 'height': 720})
        page = await context.new_page()
        
        print("Navigating to login page...")
        await page.goto(LOGIN_URL, wait_until="domcontentloaded")
        await asyncio.sleep(2)
        
        print("\n" + "="*80)
        print("FORM FIELD INSPECTION")
        print("="*80 + "\n")
        
        # Try various selectors for User ID field
        print("🔍 Searching for USER ID field...")
        user_id_selectors = [
            "[name='user']",
            "[name='username']",
            "[name='User ID']",
            "[id='user']",
            "[id='username']",
            "input[type='text']:first-of-type",
            "input[placeholder*='ID' i]",
            "input[placeholder*='user' i]",
        ]
        
        for selector in user_id_selectors:
            try:
                element = await page.query_selector(selector)
                if element:
                    info = await element.evaluate("""el => ({
                        name: el.name,
                        id: el.id,
                        type: el.type,
                        placeholder: el.placeholder,
                        class: el.className
                    })""")
                    print(f"  ✓ Found: {selector}")
                    print(f"    Info: {json.dumps(info, indent=6)}\n")
                    break
            except:
                pass
        
        # Try various selectors for Password field
        print("🔍 Searching for PASSWORD field...")
        password_selectors = [
            "[name='password']",
            "[name='Password']",
            "[id='password']",
            "input[type='password']",
            "input[placeholder*='password' i]",
        ]
        
        for selector in password_selectors:
            try:
                element = await page.query_selector(selector)
                if element:
                    info = await element.evaluate("""el => ({
                        name: el.name,
                        id: el.id,
                        type: el.type,
                        placeholder: el.placeholder,
                        class: el.className
                    })""")
                    print(f"  ✓ Found: {selector}")
                    print(f"    Info: {json.dumps(info, indent=6)}\n")
                    break
            except:
                pass
        
        # Try various selectors for Sign In button
        print("🔍 Searching for SIGN IN button...")
        button_selectors = [
            "button:has-text('Sign in')",
            "button:has-text('Sign In')",
            "[value='Sign in']",
            "[value='Sign In']",
            "input[type='submit']:has-text('Sign in')",
            "input[type='submit']:has-text('Sign In')",
            "button[name='SignIn']",
            "button",
            "input[type='submit']",
        ]
        
        buttons = await page.query_selector_all("button")
        if buttons:
            print(f"  Found {len(buttons)} button(s):")
            for i, btn in enumerate(buttons):
                text = await btn.evaluate("el => el.textContent?.trim()")
                info = await btn.evaluate("""el => ({
                    type: el.type,
                    class: el.className,
                    id: el.id,
                    name: el.name,
                    value: el.value
                })""")
                print(f"    [{i}] Text: '{text}'")
                print(f"        Info: {json.dumps(info, indent=8)}\n")
        
        # Get all form inputs
        print("\n" + "="*80)
        print("ALL FORM INPUTS:")
        print("="*80 + "\n")
        
        inputs = await page.query_selector_all("input")
        for i, inp in enumerate(inputs):
            info = await inp.evaluate("""el => ({
                type: el.type,
                name: el.name,
                id: el.id,
                placeholder: el.placeholder,
                class: el.className
            })""")
            print(f"Input [{i}]: {json.dumps(info, indent=2)}")
        
        # Save a detailed HTML snapshot
        html = await page.content()
        with open("page_source.html", "w") as f:
            f.write(html)
        print("\n✓ Full page HTML saved to 'page_source.html'")
        
        # Keep browser open for manual inspection
        print("\n" + "="*80)
        print("Browser kept open for manual inspection. Press ENTER to close...")
        print("="*80)
        input()
        
        await browser.close()


if __name__ == "__main__":
    asyncio.run(inspect_page())
