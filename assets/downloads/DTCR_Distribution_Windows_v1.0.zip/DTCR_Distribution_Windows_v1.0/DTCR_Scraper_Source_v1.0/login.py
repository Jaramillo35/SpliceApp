"""
Chrysler Login Script
This script automates the login process for the Chrysler website using Playwright and Chromium.
"""

import asyncio
import getpass
import os
import sys
from pathlib import Path
from playwright.async_api import async_playwright
from dotenv import load_dotenv
import logging

# Load environment variables from .env file
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Chrysler login URL
LOGIN_URL = "https://login.chrysler.com/siteminderagent/forms/chryslerlogin.fcc?TYPE=33554433&REALMOID=06-3f2a4016-f13a-0076-0000-31e7000031e7&GUID=&SMAUTHREASON=0&METHOD=GET&SMAGENTNAME=-SM-%2bWLpSgscRfpSwghGeXnNG1dvGOs%2bFyz1jzikB8V%2fvy%2bVofPVokIbhkuBaeIevVBwV5%2fnWaXHP4IzVfRYlCE7Gg3OqtvJTcVV&TARGET=-SM-https%3a%2f%2fispeed%2eextra%2echrysler%2ecom%2fispeed%2findex%2ehtml"

# Selectors for form elements - found via page inspection
USERNAME_INPUT_SELECTOR = "[name='USER']"  # User ID input field (id='user-id')
PASSWORD_INPUT_SELECTOR = "[name='PASSWORD']"  # Password input field (id='user-pwd')
LOGIN_BUTTON_SELECTOR = "[id='login-btn']"  # Sign In button (type='submit')


async def prompt_credentials(interactive=True):
    """
    Get credentials from user input, environment variables, or return None for demo mode.
    
    Args:
        interactive (bool): If True, prompt for input. If False, use env vars or return None.
    
    Returns:
        tuple: (username, password) or (None, None)
    """
    # Try environment variables first
    username = os.getenv('CHRYSLER_USERNAME')
    password = os.getenv('CHRYSLER_PASSWORD')
    
    if username and password:
        logger.info("✓ Loaded credentials from environment variables")
        return username, password
    
    if not interactive:
        logger.warning("No credentials provided. Running in demo mode (navigation only).")
        return None, None
    
    print("\n" + "="*50)
    print("Chrysler Login Automation")
    print("="*50)
    print("You can also set CHRYSLER_USERNAME and CHRYSLER_PASSWORD environment variables")
    print("to avoid entering credentials each time.\n")
    
    username = input("Enter your Chrysler username: ").strip()
    if not username:
        logger.error("Username cannot be empty")
        return None, None
    
    password = getpass.getpass("Enter your Chrysler password: ")
    if not password:
        logger.error("Password cannot be empty")
        return None, None
    
    return username, password


async def login_chrysler(username=None, password=None, headless=False, demo_mode=False):
    """
    Perform the login to Chrysler website.
    
    Args:
        username (str): Chrysler username (optional for demo mode)
        password (str): Chrysler password (optional for demo mode)
        headless (bool): Whether to run browser in headless mode (default: False for debugging)
        demo_mode (bool): If True, only navigate and take screenshot without login
    
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        logger.info("Launching Chromium browser...")
        async with async_playwright() as p:
            # Launch Chromium browser with additional options
            browser = await p.chromium.launch(
                headless=headless,
                args=['--disable-blink-features=AutomationControlled']
            )
            context = await browser.new_context(
                viewport={'width': 1280, 'height': 720}
            )
            page = await context.new_page()
            
            logger.info(f"Navigating to login page...")
            try:
                await page.goto(LOGIN_URL, wait_until="domcontentloaded", timeout=15000)
            except Exception as e:
                logger.warning(f"Navigation warning: {e}")
            
            # Wait for page to stabilize
            await asyncio.sleep(2)
            logger.info("Page loaded. Taking initial screenshot...")
            
            # Take screenshot of login page
            await page.screenshot(path="login_page_screenshot.png")
            logger.info("✓ Screenshot saved as 'login_page_screenshot.png'")
            
            # If not in demo mode and we have credentials, try to login
            if not demo_mode and username and password:
                logger.info("Attempting to fill login form...")
                
                # Try to find and fill username field
                try:
                    await page.wait_for_selector(USERNAME_INPUT_SELECTOR, timeout=5000)
                    logger.info("✓ Found User ID field")
                    await page.fill(USERNAME_INPUT_SELECTOR, username)
                    logger.info(f"✓ Entered username: {username}")
                except Exception as e:
                    logger.error(f"✗ Could not find User ID field: {e}")
                    return False
                
                # Try to find and fill password field
                try:
                    await page.wait_for_selector(PASSWORD_INPUT_SELECTOR, timeout=5000)
                    logger.info("✓ Found Password field")
                    await page.fill(PASSWORD_INPUT_SELECTOR, password)
                    logger.info("✓ Entered password")
                except Exception as e:
                    logger.error(f"✗ Could not find Password field: {e}")
                    return False
                
                # Try to click login button
                try:
                    await page.wait_for_selector(LOGIN_BUTTON_SELECTOR, timeout=5000)
                    logger.info("✓ Found Sign In button")
                    
                    # Click the button
                    await page.click(LOGIN_BUTTON_SELECTOR)
                    logger.info("✓ Clicked Sign In button")
                    
                    # Wait for navigation/response after login
                    logger.info("Waiting for login response...")
                    try:
                        await page.wait_for_load_state("networkidle", timeout=10000)
                        logger.info("✓ Page loaded after login")
                    except Exception as e:
                        logger.warning(f"Network idle timeout (may still be loading): {e}")
                    
                    # Wait a bit more for any redirects
                    await asyncio.sleep(2)
                    
                    # Take screenshot of result
                    await page.screenshot(path="login_result_screenshot.png")
                    logger.info("✓ Screenshot saved as 'login_result_screenshot.png'")
                    
                except Exception as e:
                    logger.error(f"✗ Could not find or click Sign In button: {e}")
                    return False
            elif demo_mode:
                logger.info("Demo mode: skipping login form submission")
            else:
                logger.info("No credentials provided: demo mode (navigation only)")
            
            # Print current URL
            current_url = page.url
            logger.info(f"Current URL: {current_url}")
            
            # Close browser
            await browser.close()
            logger.info("Browser closed")
            
            return True
            
    except Exception as e:
        logger.error(f"Error during login: {e}")
        import traceback
        traceback.print_exc()
        return False


async def main():
    """Main function to run the login script."""
    logger.info("Starting Chrysler login automation...\n")
    
    # Parse command line arguments
    demo_mode = '--demo' in sys.argv or '-d' in sys.argv
    headless_mode = '--headless' in sys.argv or '-h' in sys.argv
    non_interactive = '--non-interactive' in sys.argv or '-n' in sys.argv
    
    if demo_mode:
        logger.info("Running in DEMO MODE (navigation only, no login)")
    
    # Get credentials
    username, password = await prompt_credentials(interactive=not non_interactive)
    
    if non_interactive and not username:
        logger.error("Non-interactive mode requires CHRYSLER_USERNAME and CHRYSLER_PASSWORD env vars")
        return
    
    # Perform login
    success = await login_chrysler(
        username=username,
        password=password,
        headless=headless_mode,
        demo_mode=demo_mode
    )
    
    if success:
        logger.info("\n✓ Script completed successfully!")
    else:
        logger.error("\n✗ Script encountered errors.")


if __name__ == "__main__":
    print("\n" + "="*60)
    print("Chrysler Login Automation Script")
    print("="*60)
    print("Usage: python login.py [options]")
    print("\nOptions:")
    print("  --demo, -d              Run in demo mode (navigation only, no login)")
    print("  --headless, -h          Run browser in headless mode (no visible window)")
    print("  --non-interactive, -n   Non-interactive mode (uses env vars only)")
    print("\nEnvironment Variables:")
    print("  CHRYSLER_USERNAME       Your Chrysler username")
    print("  CHRYSLER_PASSWORD       Your Chrysler password")
    print("="*60 + "\n")
    
    asyncio.run(main())
