DTCR SCRAPER - WINDOWS DISTRIBUTION

Download this zip and follow INSTALL_WINDOWS.txt.

This package includes:
- Source files from DTCRs app
- build_windows.bat (one-click build on Windows)
- INSTALL_WINDOWS.txt (step-by-step install guide)
