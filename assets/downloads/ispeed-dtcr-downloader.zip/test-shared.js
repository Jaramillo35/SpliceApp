const assert = require("node:assert/strict");
const { cleanAttachmentName, isExcludedStatus, makeSummaryCsv } = require("./shared.js");

assert.equal(cleanAttachmentName("2028_RU_UPDATE .xls***", "49951"), "49951 - 2028_RU_UPDATE.xls");
assert.equal(cleanAttachmentName("bad<>name?.pdf]", "42"), "42 - bad__name_.pdf");
assert.equal(cleanAttachmentName("folder\\drawing.dwg", "7"), "7 - drawing.dwg");
assert.equal(isExcludedStatus("Deleted"), true);
assert.equal(isExcludedStatus("CANCELED"), true);
assert.equal(isExcludedStatus("Cancelled by administrator"), true);
assert.equal(isExcludedStatus("Complete"), false);

const csv = makeSummaryCsv([{ dtcr: "1", status: "Complete", reasons: ['A, "B"'], files: ["1 - file.pdf"], result: "Downloaded" }]);
assert.match(csv, /"A, ""B"""/);
assert.match(csv, /1 - file\.pdf/);

console.log("shared helper tests passed");
